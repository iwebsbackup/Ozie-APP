class AppConfig {
  /// ozie-api base URL (keep trailing slash).
  static const String baseUrl = 'https://demo.orderezee.com/ozie-api/index.php?route=';

  /// Razorpay PUBLIC key id (safe in app). Secret stays on server only.
  static const String razorpayKeyId = 'rzp_test_U1A0oRdsQCzOld';

  /// Set in main() after Firebase.initializeApp() succeeds.
  static bool firebaseReady = false;
}