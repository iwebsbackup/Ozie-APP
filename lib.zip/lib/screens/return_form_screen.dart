import 'dart:async';

import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

import '../core/api_client.dart';
import '../core/retailer_service.dart';
import '../core/returns_models.dart';
import '../widgets/app_widgets.dart';

/// New return request. Pick invoice -> pick items + qty (bottles) -> reason
/// + resolution -> submit. Pops with `true` on success.
/// API: GET returns?action=search_invoices|fetch_invoice,
///      POST returns action=submit_return.
class ReturnFormScreen extends StatefulWidget {
  const ReturnFormScreen({super.key});

  @override
  State<ReturnFormScreen> createState() => _ReturnFormScreenState();
}

class _ReturnFormScreenState extends State<ReturnFormScreen> {
  static const List<String> _reasons = [
    'Damaged goods',
    'Expired goods',
    'Wrong product delivered',
    'Short delivery',
    'Other',
  ];
  static const List<String> _resolutions = ['Credit Note', 'Replacement'];

  final _invCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  Timer? _debounce;

  List<ReturnInvoiceSuggestion> _suggestions = [];
  bool _searching = false;

  ReturnInvoiceDetail? _invoice;
  bool _loadingInvoice = false;
  // product row index -> bottles to return
  final Map<int, int> _qty = {};

  String _reason = _reasons.first;
  String _resolution = _resolutions.first;
  bool _submitting = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _invCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  void _onInvoiceChanged(String v) {
    _debounce?.cancel();
    if (_invoice != null && v.trim() != _invoice!.invoiceNumber) {
      setState(() {
        _invoice = null;
        _qty.clear();
      });
    }
    final q = v.trim();
    if (q.length < 2) {
      setState(() => _suggestions = []);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      setState(() => _searching = true);
      try {
        final r = await RetailerService.searchReturnInvoices(q);
        if (!mounted) return;
        setState(() {
          _suggestions = r;
          _searching = false;
        });
      } on ApiException {
        if (!mounted) return;
        setState(() => _searching = false);
      }
    });
  }

  Future<void> _pickInvoice(ReturnInvoiceSuggestion s) async {
    FocusScope.of(context).unfocus();
    _invCtrl.text = s.invoiceNumber;
    setState(() {
      _suggestions = [];
      _loadingInvoice = true;
      _invoice = null;
      _qty.clear();
    });
    try {
      final d = await RetailerService.fetchReturnInvoice(s.invoiceNumber);
      if (!mounted) return;
      setState(() {
        _invoice = d;
        _loadingInvoice = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _loadingInvoice = false);
      showStatus(context, e.message, error: true);
    }
  }

  double get _credit {
    final inv = _invoice;
    if (inv == null) return 0;
    var sum = 0.0;
    _qty.forEach((i, q) {
      if (i < inv.items.length) sum += q * inv.items[i].bottlePrice;
    });
    return sum;
  }

  int get _selectedCount => _qty.values.where((q) => q > 0).length;

  void _setQty(int i, int q, int max) {
    final v = q.clamp(0, max);
    setState(() {
      if (v == 0) {
        _qty.remove(i);
      } else {
        _qty[i] = v;
      }
    });
  }

  Future<void> _submit() async {
    final inv = _invoice;
    if (inv == null) {
      showStatus(context, 'Select an invoice first.', error: true);
      return;
    }
    if (_selectedCount == 0) {
      showStatus(context, 'Select at least one item to return.', error: true);
      return;
    }
    final items = <Map<String, dynamic>>[];
    _qty.forEach((i, q) {
      if (q <= 0 || i >= inv.items.length) return;
      final it = inv.items[i];
      items.add({
        'product_id': it.productId,
        'product_name': it.productName,
        'return_quantity': q,
        'original_price': it.bottlePrice,
        'units_per_case': it.unitsPerCase,
      });
    });

    setState(() => _submitting = true);
    try {
      final msg = await RetailerService.submitReturn(
        invoiceNumber: inv.invoiceNumber,
        reason: _reason,
        resolutionType: _resolution,
        creditAmount: _credit,
        items: items,
        description: _descCtrl.text.trim(),
      );
      if (!mounted) return;
      showStatus(context, msg);
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      showStatus(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('New Return'),
        backgroundColor: AppColors.card,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          tooltip: 'Back',
          icon: const HugeIcon(
            icon: HugeIcons.strokeRoundedChevronLeft,
            color: AppColors.text,
            strokeWidth: 1.5,
          ),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
      ),
      bottomNavigationBar: _invoice == null ? null : _footer(),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _label('Invoice'),
          TextField(
            controller: _invCtrl,
            onChanged: _onInvoiceChanged,
            decoration: inputDecoration(hint: 'Search invoice number').copyWith(
              prefixIcon: const Icon(Icons.search, size: 20, color: AppColors.muted),
              suffixIcon: _searching || _loadingInvoice
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : null,
            ),
          ),
          if (_suggestions.isNotEmpty) _suggestionList(),
          if (_invoice != null) ...[
            const SizedBox(height: 16),
            _label('Select items to return (qty in bottles)'),
            if (_invoice!.items.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('No items found on this invoice.',
                    style: TextStyle(color: AppColors.muted)),
              ),
            for (var i = 0; i < _invoice!.items.length; i++) _itemRow(i),
            const SizedBox(height: 16),
            _label('Reason'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final r in _reasons)
                  ChoiceChip(
                    label: Text(r),
                    selected: _reason == r,
                    onSelected: (_) => setState(() => _reason = r),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            _label('Resolution'),
            Wrap(
              spacing: 8,
              children: [
                for (final r in _resolutions)
                  ChoiceChip(
                    label: Text(r),
                    selected: _resolution == r,
                    onSelected: (_) => setState(() => _resolution = r),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            _label('Description (optional)'),
            TextField(
              controller: _descCtrl,
              maxLines: 3,
              decoration: inputDecoration(hint: 'Add details'),
            ),
            const SizedBox(height: 24),
          ],
        ],
      ),
    );
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          t,
          style: const TextStyle(
              fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.muted),
        ),
      );

  Widget _suggestionList() {
    return Container(
      margin: const EdgeInsets.only(top: 6),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          for (final s in _suggestions)
            ListTile(
              dense: true,
              title: Text(s.invoiceNumber,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                '${s.invoiceDate.isEmpty ? '' : '${s.invoiceDate} · '}${formatInr(s.subtotal)}',
                style: const TextStyle(fontSize: 12),
              ),
              onTap: () => _pickInvoice(s),
            ),
        ],
      ),
    );
  }

  Widget _itemRow(int i) {
    final it = _invoice!.items[i];
    final q = _qty[i] ?? 0;
    final max = it.totalBottles;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: q > 0 ? AppColors.blue : AppColors.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(it.productName,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(
            '${it.casesOrdered} case × ${it.unitsPerCase} = ${it.totalBottles} bottles'
            ' · ${formatInr(it.bottlePrice)}/bottle',
            style: const TextStyle(fontSize: 12, color: AppColors.muted),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              IconButton.outlined(
                onPressed: q > 0 ? () => _setQty(i, q - 1, max) : null,
                icon: const Icon(Icons.remove, size: 18),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Text('$q',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
              ),
              IconButton.outlined(
                onPressed: q < max ? () => _setQty(i, q + 1, max) : null,
                icon: const Icon(Icons.add, size: 18),
              ),
              const Spacer(),
              if (q > 0)
                Text(formatInr(q * it.bottlePrice),
                    style: const TextStyle(fontWeight: FontWeight.w700)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _footer() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
        decoration: const BoxDecoration(
          color: AppColors.card,
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$_selectedCount item(s)',
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.muted)),
                  Text(formatInr(_credit),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            FilledButton(
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('Submit Return'),
            ),
          ],
        ),
      ),
    );
  }
}
